package com.example.labwork23.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.labwork23.R

val robotoFontFamily = FontFamily(
    Font(R.font.roboto_condensed_light, FontWeight.Normal),
    Font(R.font.roboto_semicondensed_black, FontWeight.Bold)
)

private val LightColorScheme1 = lightColorScheme(
    primary = Color(0xFF2196F3),
    onPrimary = Color.White,
    secondary = Color(0xFF4CAF50),
    onSecondary = Color.White,
    background = Color(0xFFF5F5F5),
    surface = Color.White
)

private val DarkColorScheme1 = darkColorScheme(
    primary = Color(0xFF90CAF9),
    onPrimary = Color.Black,
    secondary = Color(0xFFA5D6A7),
    onSecondary = Color.Black,
    background = Color(0xFF121212),
    surface = Color(0xFF1E1E1E)
)

private val LightColorScheme2 = lightColorScheme(
    primary = Color(0xFF9C27B0),
    onPrimary = Color.White,
    secondary = Color(0xFFFF9800),
    onSecondary = Color.White,
    background = Color(0xFFFFF8E1),
    surface = Color.White
)

private val DarkColorScheme2 = darkColorScheme(
    primary = Color(0xFFCE93D8),
    onPrimary = Color.Black,
    secondary = Color(0xFFFFCC80),
    onSecondary = Color.Black,
    background = Color(0xFF212121),
    surface = Color(0xFF323232)
)

@Composable
fun LabWork23Theme(
    darkTheme: Boolean,
    colorStyle: Int,
    content: @Composable () -> Unit
) {
    val colorScheme = when (colorStyle) {
        1 -> if (darkTheme) DarkColorScheme1 else LightColorScheme1
        else -> if (darkTheme) DarkColorScheme2 else LightColorScheme2
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}