package com.example.labwork23

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.labwork23.screens.CreateTaskScreen
import com.example.labwork23.screens.HomeScreen
import com.example.labwork23.screens.SettingsScreen
import com.example.labwork23.ui.theme.LabWork23Theme

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var isDarkTheme by remember { mutableStateOf(false) }
            var colorStyle by remember { mutableStateOf(1) }
            var currentScreen by remember { mutableStateOf("home") }
            LabWork23Theme(darkTheme = isDarkTheme, colorStyle = colorStyle) {
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = { Text("Task Tracker", style = MaterialTheme.typography.titleLarge) },
                            navigationIcon = {
                                Button({}) { Text("Меню") }
                            },
                            actions = {
                                Button({isDarkTheme = !isDarkTheme}) {
                                    Text(if (isDarkTheme) "Светлая" else "Тёмная")
                                }

                                Button({ colorStyle = if (colorStyle == 1) 2 else 1 }) {
                                    Text("Смена палитры")
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                titleContentColor = MaterialTheme.colorScheme.onPrimary,
                                navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                                actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                            NavigationBarItem(
                                selected = currentScreen == "home",
                                onClick = { currentScreen = "home" },
                                icon = { Icon(Icons.Default.Home, contentDescription = "Главная") },
                                label = { Text("Задачи") }
                            )
                            NavigationBarItem(
                                selected = currentScreen == "create",
                                onClick = { currentScreen = "create" },
                                icon = { Icon(Icons.Default.AddBox, contentDescription = "Создать") },
                                label = { Text("Новая") }
                            )
                            NavigationBarItem(
                                selected = currentScreen == "settings",
                                onClick = { currentScreen = "settings" },
                                icon = { Icon(Icons.Default.Settings, contentDescription = "Настройки") },
                                label = { Text("Опции") }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentScreen) {
                            "home" -> HomeScreen()
                            "create" -> CreateTaskScreen()
                            "settings" -> SettingsScreen()
                        }
                    }
                }
            }
        }
    }
}
